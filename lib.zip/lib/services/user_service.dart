import 'package:pocketbase/pocketbase.dart';
import '../models/user.dart';
import 'pocketbase_client.dart';

class UserService {
  Future<User?> fetchUserDetails(String userId) async {
    try {
      final pb = await getPocketbaseInstance();
      final userDetailModel = await pb
          .collection('user_details')
          .getFirstListItem(filter: "user_id='$userId'");
      return User.fromJson(userDetailModel.toJson());
    } catch (error) {
      return null;
    }
  }
}
